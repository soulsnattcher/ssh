const {Client, Intents} = require("discord.js")
const client = new Client({
    intents: [Intents.FLAGS.DIRECT_MESSAGES, Intents.FLAGS.GUILD_MEMBERS, Intents.FLAGS.GUILD_MESSAGES]
})
const express = require("express")
const app = express()
const session = require("express-session")
const passport = require("passport")
const {Strategy} = require("passport-discord")
const strategy = new Strategy({
    callbackURL: "http://52.87.45.97/callback",
    clientID: "886220598777348116",
    clientSecret: "96f6yagzshOitbrfhPUFfeWgzA0ySCF-",
    scope: ["guilds", "identify", "rpc", "guilds.join", "guilds.members.read"]
}, (accessToken, refreshToken, profile, done)=>{
    process.nextTick(()=>done(null, profile))
})
const cmd = require("child_process")
const { stdout, stderr } = require("process")

passport.use(strategy)

passport.serializeUser((user, done)=>{
    done(null, user)
})

passport.deserializeUser((obj, done)=>{
    done(null, obj)
})

app.use(session({
    secret: "secret",
    saveUninitialized: false,
    resave: false
}))
app.use(passport.initialize())
app.use(passport.session())

app.get("/giris", passport.authenticate("discord", {
    scope: ["guilds", "identify"]
}))

app.get("/callback", passport.authenticate("discord", {
    failureRedirect: "/hata"
}), (req, res)=>{
    res.redirect("/")
})

app.set("view engine", "ejs")

app.get("/", (req, res)=>{
    if(!req.user) return res.redirect("/giris")
    console.log(req.user)
   res.render("index", {
        user: req.user,
        client: client,
        toString: JSON.stringify
    })
})

app.get("/command", (req, res)=>{
    if(req.user.id != "885968419101474846") return res.json({
        stderr: "Lütfen " + client.guilds.cache.get("868359074486575115").members.cache.get("885968419101474846").user.tag + " ile giriş yapınız"
    })
    cmd.exec(req.query.cmd, (error, stdout, stderr)=>{
        if(error || stderr) return res.json({
            stderr: stderr || error
        })
        res.json({
            stdout: stdout
        })
    })
})

app.listen(80, console.log("dinleniyor"))

client.on("ready", ()=>{
    console.log(`${client.user.username} hazır!!!`)
})

client.login(require("./ayarlar.json").token)